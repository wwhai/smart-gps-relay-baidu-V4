/* Copyright (C) www.lightembedded.com
 * 2018 - xianlee.wu xianleewu@163.com
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "stdio.h"
#include "stdint.h"
#include "stdarg.h"
#include "stdlib.h"
#include "string.h"
#include "digest/utils_hmac.h"
#include "digest/utils_md5.h"
#include "digest/utils_sha1.h"
#include "aliyun_pri.h"

#define SHA_METHOD  "hmacsha1"
#define MD5_METHOD  "hmacmd5"

#define USING_SHA1_IN_HMAC 0

int aliyun_dev_init(aliyun_dev_t* alidev,  const char* dev_name,
                    const char* dev_sec, const char* pdk,
                    const char* timestamp, const char* partner_id,
                    const char* module_id, int secmode, int gw)
{
    alidev->dev_name = dev_name;
    alidev->dev_sec = dev_sec;
    alidev->pdk = pdk;
    alidev->timestamp = timestamp;
    alidev->partner_id = partner_id;
    alidev->module_id = module_id;
    alidev->secmode = secmode;
    alidev->gw = gw;

    memset(alidev->dev_id, 0, DEVID_MAX_LEN);

    aliyun_deviceid_gen(alidev->dev_id, DEVID_MAX_LEN, alidev);

    return 0;
}

int aliyun_deviceid_gen(char* devid, int len, aliyun_dev_t* alidev)
{
    snprintf(devid, len, "%s.%s", alidev->pdk, alidev->dev_name);

    return 0;
}

int fill_conn_string(char *dst, int len, const char *fmt, ...)
{
    int rc = -1;
    va_list ap;
    char *ptr = NULL;

    va_start(ap, fmt);
    rc = vsnprintf(dst, len, fmt, ap);
    va_end(ap);

    if (rc > len) {
        return -1;
    };

    ptr = strstr(dst, "||");
    if (ptr) {
        *ptr = '\0';
    }

    return 0;
}

int aliyun_clientid_gen(char* client_id, int len, aliyun_dev_t* alidev)
{
    fill_conn_string(client_id, len,
                      "%s"
                      "|securemode=%d"
#if USING_SHA1_IN_HMAC
                      ",timestamp=%s,signmethod=" SHA_METHOD ",gw=%d"
#else
                      ",timestamp=%s,signmethod=" MD5_METHOD ",gw=%d"
#endif
                      "%s"
                      "%s"
                      "|"
                      , alidev->dev_id
                      , alidev->secmode
                      , alidev->timestamp
                      , alidev->gw
                      , alidev->partner_id
                      , alidev->module_id);
    return 0;
}

int aliyun_username_gen(char* username, int len, aliyun_dev_t* alidev)
{
    snprintf(username, len, "%s&%s", alidev->dev_name, alidev->pdk);

    return 0;
}

int aliyun_password_gen(char* password, int len, aliyun_dev_t* alidev)
{
    int source_len = -1;
    char source[256] = {0};

    if (len < 16) {
        printf("password buf is too samll!\n");
        return -1;
    }

    source_len = snprintf(source, 256, "clientId%s" "deviceName%s" "productKey%s" "timestamp%s",
                        alidev->dev_id, alidev->dev_name, alidev->pdk, alidev->timestamp);

    utils_hmac_md5(source, strlen(source), password, alidev->dev_sec, strlen(alidev->dev_sec));

    printf("\n----->MD5 signature source:%s\n", source);
    printf("\n----->MD5 signature:%s\n", password);

    return (source_len > 0) ? 0 : -1;
}

