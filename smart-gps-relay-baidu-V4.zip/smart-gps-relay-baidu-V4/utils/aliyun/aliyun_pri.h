/* Copyright (C) www.lightembedded.com
 * 2018 - xianlee.wu xianleewu@163.com
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __ALIYUN_PRI_H__
#define __ALIYUN_PRI_H__

#define DEVID_MAX_LEN   64

typedef struct _aliyun_dev {
    const char* dev_name; // device name from aliyun
    const char* dev_sec; // device secret from aliyun
    const char* pdk;  // product key from aliyun
    const char* timestamp; // none using now
    const char* partner_id; // set by user
    const char* module_id; // set by user
    char dev_id[DEVID_MAX_LEN]; // generated when do dev init
    int gw; // gw default 0
    int secmode; // secret mode, default 3, direct connect
} aliyun_dev_t;

int aliyun_dev_init(aliyun_dev_t* alidev,  const char* dev_name,
                    const char* dev_sec, const char* pdk,
                    const char* timestamp, const char* partner_id,
                    const char* module_id, int secmode, int gw);

int aliyun_deviceid_gen(char* devid, int len, aliyun_dev_t* alidev);

int aliyun_clientid_gen(char* client_id, int len, aliyun_dev_t* alidev);

int aliyun_username_gen(char* username, int len, aliyun_dev_t* alidev);

int aliyun_password_gen(char* password, int len, aliyun_dev_t* alidev);

#endif
