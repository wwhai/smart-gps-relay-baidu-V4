#ifndef __USER_TASKS_H__
#define __USER_TASKS_H__

#include "stdint.h"

void update_current_time(void);

void user_task_loop(void);

void timer_task_loop(void);

int read_rfid(char* rfid);

extern uint8_t beep_once[];

#endif
