/* Copyright (C) www.lightembedded.com
 * 2018 - xianlee.wu xianleewu@163.com
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "simdevice.h"
#include "frozen.h"
#include "relay.h"
#include "delay.h"
#include "parameter.h"
#include "mqtt-user.h"
#include "timer_task.h"
#include "user_task.h"
#include "aliyun_pri.h"
#include "MQTTPacket.h"

#define USING_ALIIOT

double curr_lng = 0.0;
double curr_lat = 0.0;
int curr_state = 0;

timer_task_t relay_control_task;

int check_tcp_func(void* arg)
{
    if(!simdevice_check_connection()) {
        conn_state.error_count++;
        conn_state.connected = 0;
    }

    return 0;
}

char* find_mqtt_start(char* buf, int len)
{
    int i = 0;
    int cr_count = 0;

    for (i=0;i<len-1;i++) {
        if (buf[i] == 0x0d && buf[i+1] == 0x0a) {
            cr_count++;
            if (cr_count >= 2) {
                return buf + i + 2;
            } 
        }
    }
    
    return NULL;
}

char* find_mqtt_topic(char* buf, int len)
{
    return strtok(buf, "{");
}

int rrpc_send_response(char* rrpc_id)
{
    printf("-----------------1--------------->\n");
    char topic_buf[128] = {0};

    printf("-----------------2--------------->\n");
    
    snprintf(topic_buf, 128, "/sys/%s/%s/rrpc/response/%s", ProductKey, DeviceName, rrpc_id);
    printf("--2--------------->%s\n", topic_buf);
    mqtt_send_beat(topic_buf, curr_state);
    
    return 0;
}

/*
 *{"cmd":"relay","type":"control","data":"0"}
 *{"cmd":"relay","type":"control","data":"1"}
 *{"cmd":"relay","type":"time","data":"10"}
 * {"method":"thing.service.property.set","id":"1053438303","params":{"Lock_control":1},"version":"1.0.0"}
 */
int read_tcp_func(void* arg)
{
    char* json_start = NULL;
    char* json_end = NULL;
    int json_len = -1;
    int i = 0;

    char* cmd = NULL;
    char* type = NULL;
    char* data = NULL;

    char temp_buf[128] = {0};
    char* mqtt_topic = NULL;
    char rrpc_id[32] = {0};
    
    unsigned char* mqtt_raw_start = NULL;
    unsigned char dup[8] = {0};
    unsigned char retained[8] = {0};
    unsigned char* payload = NULL;
    int qos = -1;
    unsigned short packetid = -1;
    int payloadlen = -1;
    MQTTString topicName;
    
    simdevice_read_tcp(NULL, 0);

    gsm_global_data.frame_buf[GSM_DATA_RECORD_MAX_LEN - 1] = '\0';

    json_start = gsm_global_data.frame_buf;

    for (i=0;i<GSM_DATA_RECORD_MAX_LEN;i++) {
        if (*json_start == '{') {
            break;
        }
        json_start++;
    }

    if (NULL == json_start) {
        return 0;
    }
    
    json_end = json_start;

    for (i=0;i<GSM_DATA_RECORD_MAX_LEN;i++) {
        if (*json_end == '}') {
            break;
        } else if (*json_end == '\0') {
            json_end = NULL;
            break;
        }
        json_end++;
    }

    if (NULL == json_end) {
        return 0;
    }

    json_len = json_end -json_start;

    if (json_len < 5) {
        return 0;
    }
    
    mqtt_raw_start = (unsigned char*)find_mqtt_start(gsm_global_data.frame_buf, GSM_DATA_RECORD_MAX_LEN);

    MQTTDeserialize_publish(dup, &qos, retained, &packetid, &topicName,
		&payload, &payloadlen, mqtt_raw_start, GSM_DATA_RECORD_MAX_LEN);
    
    memcpy(temp_buf, topicName.lenstring.data, 128);
    
    mqtt_topic = find_mqtt_topic(temp_buf, 128);
    
    sscanf(mqtt_topic, "/sys/%*[^/]/%*[^/]/rrpc/request/%s", rrpc_id);

    printf("Message From Topic[%s][%s]\n", mqtt_topic, rrpc_id);
    
    printf("MSG IN--->\n%s\n", json_start);

    json_scanf(json_start, json_len, "{cmd:%Q,type:%Q,data:%Q}", &cmd, &type, &data);

    if (0 == strncmp(cmd, "relay", 5)) {
        if (0 == strncmp(type, "control", 7)) {
            if (atoi(data) > 0) {
                printf("relay cmd on!\n");
                relay_on();
                curr_state = 1;
            } else {
                printf("relay cmd off!\n");
                relay_off();
                curr_state = 0;
            }
            rrpc_send_response(rrpc_id);
        } else if (0 == strncmp(type, "time", 5)) {
            printf("relay will turn off in:%d secooneds!\n", atoi(data));
            relay_on();
            relay_control_task.last_time = curr_time;
            relay_control_task.next_time = atoi(data);
            rrpc_send_response(rrpc_id);
        }
    } else if (0 == strncmp(cmd, "get", 3)) {
        if (0 == strncmp(type, "state", 5)) {
            rrpc_send_response(rrpc_id);
        }
    } else {
        printf("unsupported cmd!\n");
    }

    if (cmd)
        free(cmd);
    if (type)
        free(type);
    if (data)
        free(data);

    return 0;
}

int send_ping_func(void* arg)
{
    mqtt_ping();
    
    return 0;
}

int send_heartbeat_func(void* arg)
{
    return mqtt_send_beat(pub_topic, curr_state);
}

int relay_control_func(void* arg)
{
    relay_control_task.next_time = 0;
    relay_off();
    curr_state = 0;
    return 0;
}

int send_gnss_func(void* arg)
{
    get_gps_info(&curr_lng, &curr_lat);

    return 0;
}

int mqtt_connect_func(void* arg)
{
    // ����������γ�������������
    if (!conn_state.connected || conn_state.error_count > 2) {
        printf("=try to connect mqtt server now[%d]=\n", conn_state.error_count);
        
#ifdef USING_ALIIOT
        aliyun_dev_t alidev;
        aliyun_dev_init(&alidev, DeviceName, DeviceSecret, ProductKey, "2524608000000",
                        "example.demo.partner-id", "example.demo.module-id", 3, 0);

        memset(client_id, 0, 256);
        memset(username, 0, 128);
        memset(password, 0, 128);
        memset(sub_topic, 0, 64);
        memset(server_addr, 0, 128);
        
        aliyun_clientid_gen(client_id, 256, &alidev);
        aliyun_username_gen(username, 128, &alidev);
        aliyun_password_gen(password, 128, &alidev);
        
        snprintf(server_addr, 128, "%s.iot-as-mqtt.cn-shanghai.aliyuncs.com", ProductKey);
        //snprintf(sub_topic, 64, "/%s/%s/update", ProductKey, DeviceName);
        snprintf(sub_topic, 64, "/%s/%s/rrpc/request/#", ProductKey, DeviceName);
#else
        /* ���ｫclientid����Ϊdevice-<IMEI>��ÿ���豸����ͬ */
        /* IMEI�������豸��GSMģ��ı�ǩ�Ͽ��� */
        snprintf(client_id, 64, "device-%s", gsm_imei);
        snprintf(sub_topic, 64, "device/control/%s", gsm_imei);
#endif
        printf("sim800c device %s init ok!\n", gsm_imei);
        
        printf("\n*******MQTT INFO************\n");
        printf("CLIENTID: %s\n", client_id);
        printf("USERNAME: %s\n", username);
        printf("PASSWORD: %s\n", password);
        printf("*******END************\n");
        
        mqtt_connection_init(server_addr, server_port, client_id, username, password);
        delay_ms(2000);
        if (mqtt_state.connected) {
            mqtt_subscribe(sub_topic, 0);
#ifndef USING_ALIIOT
            mqtt_subscribe(sub_topic_all, 0);
#endif
        }
    } else {
        return 0;
    }

    // �������10�γ��������³�ʼ��
    if (conn_state.error_count > 3) {
        printf("========try to reinit simdevice now=========\n");
        simdevice_close_net();
        simdevice_set_state(&sim8xx, SIMDEV_POWER_ON);
        return 0;
    }

    // �������20�γ���������ģ��
    if (conn_state.error_count > 4) {
        printf("========try to reboot simdevice now=========\n");
        simdevice_reboot();
        simdevice_set_state(&sim8xx, SIMDEV_POWER_OFF);
        conn_state.error_count = 0;
        return 0;
    }

    return 0;
}

timer_task_t check_tcp_task = {
    .last_time = 0,
    .next_time = 5,
    .func = check_tcp_func,
};

timer_task_t send_ping_task = {
    .last_time = 0,
    .next_time = 50,
    .func = send_ping_func,
};

timer_task_t send_beat_task = {
    .last_time = 0,
    .next_time = 60,
    .func = send_heartbeat_func,
};

timer_task_t send_gnss_task = {
    .last_time = 0,
    .next_time = 5,
    .func = send_gnss_func,
};

timer_task_t relay_control_task = {
    .last_time = 0,
    .next_time = 1,
    .func = relay_control_func,
};

void user_task_loop()
{
    update_current_time();

    simdevice_state_machine(&sim8xx);

    if (sim8xx.state == SIMDEV_GPRS_READY) {
        read_tcp_func(NULL);
        mqtt_connect_func(NULL);
        timer_task_executer(&send_ping_task, NULL);
        timer_task_executer(&check_tcp_task, NULL);
        //timer_task_executer(&send_beat_task, NULL);
        timer_task_executer(&send_gnss_task, NULL);
    }
}

void timer_task_loop()
{
    timer_task_executer(&relay_control_task, NULL);
}
