#ifndef __PARAM_H__
#define __PARAM_H__

#include "stdint.h"

#define ProductKey      "a168XbasANx"
#define DeviceName      "testlock"
#define DeviceSecret    "QHwDKMwknAOaRkacRpQbWboCl2rJseN2"

#define SERVER_ADDR_MAX_LEN 4*32
#define SUPPORT_RFID    0
#define USE_WATCHDOG    1

extern char gsm_imei[];
extern char iccid[];
extern char server_addr[];
extern char server_port[];
extern char client_id[];
extern char username[];
extern char password[];
extern char sub_topic[];
extern char sub_topic_all[];
extern char pub_topic[];

typedef struct _connect_state {
	int connected;
	int error_count;
} connect_state_t;

typedef struct _system_state {
    uint32_t state;
    uint32_t startup_times;
    uint32_t sensor_param;
    char server_addr[SERVER_ADDR_MAX_LEN];
} system_state_t;

extern system_state_t sys_state;

extern connect_state_t conn_state;

extern const char sys_info[];

int tcp_send_msg(const char *msg, int len);

int tcp_send_beat(int no, int state);

int save_system_state(system_state_t* state);

int recovery_system_state(system_state_t* state);

#endif
