Add hardware driver code here.
